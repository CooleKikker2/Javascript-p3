function registerServiceWorker() {
    console.log("Register!");
}